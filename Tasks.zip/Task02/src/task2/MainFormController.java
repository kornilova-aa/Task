package task2;

import java.util.Random;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;

public class MainFormController {
	
	@FXML
	TableView<TableItem> Table;	
	@FXML
	TableColumn<TableItem, Double> ColumnK;
	@FXML
	TableColumn<TableItem, Double> ColumnY;
	@FXML
	TextField AField, BField;
	
	private ObservableList<TableItem> TItems = FXCollections.observableArrayList();
	
	double randomDouble(Random r, double min, double max) {
	    return min + (max - min) * r.nextDouble();
	}
	
	 @FXML
	 private void initialize() 
	 {
		TItems.clear();
		for(int i=0; i<10; i++) {
			TItems.add(new TableItem());
		}
		ColumnK.setCellValueFactory(new PropertyValueFactory<TableItem, Double>("K"));
		ColumnK.setCellFactory(TextFieldTableCell.<TableItem, Double>forTableColumn(new DoubleStringConverter()));
		ColumnY.setCellValueFactory(new PropertyValueFactory<TableItem, Double>("Y"));		
		
		Table.setItems(TItems);
		Table.setEditable(true);
		
		ColumnK.setEditable(true);
	 }
	 
	 @FXML
	 public void EditKCommit(CellEditEvent<TableItem, Double> t) {
		 int rowid = t.getTablePosition().getRow();
         ((TableItem)t.getTableView().getItems().get(rowid)).setK(t.getNewValue());
         for(int i=rowid; i<TItems.size(); i++) {
             ((TableItem)t.getTableView().getItems().get(i)).resetcalc();
         }
         Table.refresh();
     }
	 
	 @FXML
	 private void randomSet() 
	 {
		Random rand = new Random();
		
		AField.setText(String.valueOf(rand.nextInt(20)-10));
		BField.setText(String.valueOf(rand.nextInt(20)-10));
		
		for(int i=0; i<10; i++) {
			TItems.get(i).setK(randomDouble(rand, -10,10));
		}
		Table.refresh();
	 }
	 
	 @FXML
	 public void Exit() {
		System.exit(0);	 
	 }
	 
	 @FXML
	 public void Clear() {
		 AField.setText("");
		 BField.setText("");
		 for(int i=0; i<10; i++) {
			 TItems.get(i).clear();
		 }
		 Table.refresh();
	 }
	 
	 private void ShowMessage(String text, String title) {
		 Alert alert = new Alert(Alert.AlertType.WARNING);

		 alert.setTitle(title);
		 alert.setHeaderText(null);
		 alert.setContentText(text);

		 alert.showAndWait();
	 }
	 
	 @FXML
	 public void Calc() {
		 try {
			 double a = Double.parseDouble(AField.getText());
			 double b = Double.parseDouble(BField.getText());
			 double KSum=0;
			 for(int i=0; i<10; i++) {
				 if(TItems.get(i).Calculate(a, b, KSum)) {
					 KSum+=TItems.get(i).getK();
				 }else {
					 ShowMessage("Введены некорректные данные!", "Некорректные даные");
					 break;
				 }
			 }
			 Table.refresh();
		 }catch(Exception ex) {
			 ShowMessage("Ошибка во вводимых данных!", "Некорректные даные");
		 }		 
	 }
}
