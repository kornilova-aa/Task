package task2;

import javafx.beans.property.SimpleDoubleProperty;

public class TableItem{
	private SimpleDoubleProperty K;
	private SimpleDoubleProperty Y;
	
	public TableItem() {
		this.Y = new SimpleDoubleProperty(0);
		this.K = new SimpleDoubleProperty(1);
	}
	
	public double getY() {
		return Y.get();
	}
	
	public void setY(double Yval) {
		this.Y.set(Yval);
	}
	
	public double getK() {
		return K.get();
	}
	
	public void setK(double Kval) {
		this.K.set(Kval);
		this.Y.set(0);
	}
	
	public void resetcalc() {
		this.Y.set(0);
	}
	
	public void clear() {
		this.Y.set(0);
		this.K.set(1);
	}
	
	public boolean Calculate(double a, double b, double KSum) {
		try {
			if((K.get()==a)&& (a==b) && b==0) {
				return false;
			}else if(a==b && b==0) {
				return false;
			}else {
				this.Y.set(Math.sqrt(Math.pow(Math.cos(K.get()), 2) / ((Math.pow(a, 2) + Math.pow(b, 2)) - Math.sin(K.get())))*KSum);
				return true;
			}
		}catch(Exception ex) {
			return false;
		}
	}
}
