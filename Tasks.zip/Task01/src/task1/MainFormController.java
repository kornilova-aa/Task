package task1;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class MainFormController {
	@FXML
	TextField XText, AText, BText, ResultText;
	
	@FXML
	public void Clear() {
		XText.clear();
		AText.clear();
		BText.clear();
		ResultText.clear();
	}
	
	private String getResult(double x, double a, double b) {
		if(x>7) {
			double ret = Math.pow(a+b, 2)*x;
			return String.valueOf(ret);
		}else if(!(a==b&&a==0)){
			double ret = (x+4)/(Math.pow(a, 2)+Math.pow(b, 2));
			return String.valueOf(ret);
		}else {
			return "A и B одновременно равны нулю!";
		}
	}
	
	@FXML
	public void Calc() {
		try {
			double x = Double.parseDouble(XText.getText());
			double a = Double.parseDouble(AText.getText());
			double b = Double.parseDouble(BText.getText());
			
			ResultText.setText(getResult(x,a,b));
		}catch(Exception e){
			ResultText.setText("Ошибка при обработке значений!");
		}
		
	}
	
	@FXML
	public void Exit() {
		System.exit(0);
	}
}
