package task3;

import java.util.Random;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.Callback;
import javafx.util.converter.IntegerStringConverter;

public class MainFormController {
	@FXML
	Label MaxLabel, MinLabel;
	@FXML
	TableView<int[]> Table;
	
	ObservableList<int[]> IntArr = FXCollections.observableArrayList();
	
	@FXML
	private void initialize() 
	{
		int c = 5;
		for(int i=0; i<c; i++) {
			IntArr.add(new int[c]);
			for(int r=0; r<c; r++) {
				IntArr.get(i)[r]=0;
			}
		}
		
		for(int i=0; i<c; i++) {
			TableColumn<int[], Integer> tc = new TableColumn<int[], Integer>("c"+String.valueOf(i+1));			
			
			final int id = i;
			tc.setCellValueFactory(new Callback<CellDataFeatures<int[], Integer>, ObservableValue<Integer>>() {
				@Override
				public ObservableValue<Integer> call(CellDataFeatures<int[], Integer> arg) {
					return new ReadOnlyObjectWrapper<>(arg.getValue()[id]);
				}
			});
			tc.setCellFactory(TextFieldTableCell.<int[], Integer>forTableColumn(new IntegerStringConverter()));
			tc.setOnEditCommit(new EventHandler<CellEditEvent<int[], Integer>>(){
				@Override
				public void handle(CellEditEvent<int[], Integer> arg) {
					int rowid = arg.getTablePosition().getRow();
					((int[])arg.getTableView().getItems().get(rowid))[id]=arg.getNewValue();					
				}
			});
			tc.setEditable(true);
			tc.setPrefWidth(Table.getPrefWidth()/c-1);
			
			
			Table.getColumns().add(tc);
		}
		
		Table.setItems(IntArr);
		Table.setEditable(true);
	}
	
	@FXML
	private void setRandom(){
		Random rand = new Random();
		for(int i=0; i<IntArr.size(); i++) {
			for(int r=0; r<IntArr.get(i).length; r++) {
				IntArr.get(i)[r] = rand.nextInt(20)-10;
			}
		}
		Table.refresh();
	}
	
	@FXML
	private void calculate(){
		int min=IntArr.get(0)[0], max=min;
		for(int i=0; i<IntArr.size(); i++) {
			for(int r=0; r<IntArr.get(i).length; r++) {
				if(min>IntArr.get(i)[r]) {
					min=IntArr.get(i)[r];
				}else if(max<IntArr.get(i)[r]) {
					max=IntArr.get(i)[r];
				}
			}
		}
		
		MaxLabel.setText(String.valueOf(max));
		MinLabel.setText(String.valueOf(min));
		
		if((max-min)/10>=1) {
			for(int i=0; i<IntArr.size(); i++) {
				for(int r=0; r<IntArr.get(i).length; r++) {
					if(IntArr.get(i)[r]==0) {
						IntArr.get(i)[r]=1;
					}else if(IntArr.get(i)[r]<0) {
						IntArr.get(i)[r]=Math.abs(IntArr.get(i)[r]);
					}
				}
			}
		}
		
		Table.refresh();
	}
}
